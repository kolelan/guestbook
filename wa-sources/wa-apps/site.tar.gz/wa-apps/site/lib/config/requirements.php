<?php
return array(
    'app.installer'=>array(
        'version'=>'>=1.10.0',
        'strict'=>true,
    ),
);
//EOF