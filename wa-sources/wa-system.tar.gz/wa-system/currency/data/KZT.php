<?php

return array(
    'code' => 'KZT',
    'sign' => 'T',
	'iso4217' => '398',
    'title' => 'Kazakhstani tenge',
    'name' => array(
        array('tenge', 'tenges'),
    ),
    'frac_name' => array(
	  array('tïın', 'tïıns'),
    )
);