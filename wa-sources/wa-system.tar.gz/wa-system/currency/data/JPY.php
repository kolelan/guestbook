<?php

return array(
    'code' => 'JPY',
    'sign' => '¥',
	'iso4217' => '392',
    'sign_position' => 0,
    'sign_delim' => '',
    'title' => 'Japanese yen',
    'name' => array(
        'yen',
    ),
    'frac_name' => array(
    )
);