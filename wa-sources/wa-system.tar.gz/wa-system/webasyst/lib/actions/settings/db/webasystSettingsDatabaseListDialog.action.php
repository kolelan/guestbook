<?php

class webasystSettingsDatabaseListDialogAction extends webasystSettingsViewAction
{
    public function execute()
    {
        // Yep yep :]
    }
}